package com.example.chordnote.data.prefs;

public interface PreferencesHelper {
}
