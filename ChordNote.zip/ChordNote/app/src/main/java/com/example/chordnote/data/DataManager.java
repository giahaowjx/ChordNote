package com.example.chordnote.data;

public class DataManager {
}
