package com.example.chordnote.data.db;


import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class DbHelperImpl implements DbHelper {

//    private DaoSession mDaoSession;
//
//    @Inject
//    public DbHelperImpl(DbOpenHelper dbOpenHelper) {
//        mDaoSession = new DaoMaster(dbOpenHelper.getWritableDb()).newSession();
//    }

}
