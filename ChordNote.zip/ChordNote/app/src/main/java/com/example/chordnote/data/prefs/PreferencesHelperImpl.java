package com.example.chordnote.data.prefs;

public class PreferencesHelperImpl implements PreferencesHelper {
}
