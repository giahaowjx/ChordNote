package com.example.chordnote.data.db;

public interface DbHelper {
}
