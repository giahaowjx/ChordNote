package com.example.chordnote.di.module;


import android.support.v7.app.AppCompatActivity;

import dagger.Module;

@Module
public class ActivityModule {

    private AppCompatActivity mActivity;

    public ActivityModule(AppCompatActivity activity) {
        mActivity = activity;
    }

}
